#!/usr/bin/php
<?php

include_once "phpagi-2.20/phpagi.php";

$agi = new AGI();

$exten = $agi->get_variable("EXTEN");
$agi->exec("Noop","Dado\ do\ exten:\ ".$exten['data']);

$agi->set_variable("EXTENMANIPULADO", "000".$exten['data']);
$extenmanipulado = $agi->get_variable("EXTENMANIPULADO");

$agi->exec("Noop","Dado\ manipulado\ ".$extenmanipulado['data']);
