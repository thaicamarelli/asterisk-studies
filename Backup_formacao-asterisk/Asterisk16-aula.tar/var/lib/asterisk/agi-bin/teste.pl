#!/usr/bin/perl

use Asterisk::AGI;

$AGI = new Asterisk::AGI;

$AGI->answer();
$AGI->exec("Noop","PEERL");
$AGI->exec("Playback","pbx-invalid");
