#!/usr/bin/php

<?php

include_once "phpagi-2.20/phpagi.php";

$agi = new AGI(); /* instanciar o AGI objeto classe*/

$exten = $agi->get_variable("EXTEN"); /* Pego a variavel exten */
$extenreal = substr($exten['data'], 2); /* corto os dois primeiros digitos que eu digitei */

$hostname = "localhost";
$username = "root";
$password = "Z@Psuporte10";
$dbname = "agi";

$connect = new mysqli($hostname,$username,$password,$dbname);
if (mysqli_connect_errno()) trigger_error(mysqli_connect_error());

$executa = mysqli_query($connect,"SELECT * FROM numbers WHERE number='$extenreal'"); /* executo a query */

if(mysql_num_rows($executa) > 0){ /* se retornou linha eu toco audio */
	$agi->exec("Playback","pbx-invalid");
}else{
	$agi->exec("Hangup");
}


