#!/usr/bin/python

from asterisk.agi import *

agi = AGI()

agi.appexec("Noop","Pythonzera")
agi.appexec("Playback","tt-monkeys")
