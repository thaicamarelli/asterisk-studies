#!/usr/bin/php
<?php

include_once "phpagi-2.20/phpagi.php";

$agi = new AGI();

$agi->answer();
$agi->exec("Noop","Teste");
$agi->exec("Playback","tt-monkeys");

